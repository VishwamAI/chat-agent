# Pull Request: Update Features for VishwamAI

## Description
This pull request includes the following updates and enhancements to the VishwamAI project:

### New Features
- **Auto-Update**: Implemented an auto-update feature to ensure the model and its dependencies are always up-to-date.
- **Continuous Evaluation**: Added a continuous evaluation script to monitor and log the model's performance over time.
- **Integration with `grok-1` Model**: Assessed the potential integration of the `grok-1` model to enhance VishwamAI's capabilities.

### Updated Scripts
- **setup.sh**: Updated to install Google Chrome and bypass Docker daemon restart prompts.
- **auto_update.py**: Manages system package updates and pulls changes from the VishwamAI GitHub repository.
- **continuous_evaluation.py**: Performs performance evaluation of the VishwamAI model and logs performance metrics.

### Model Enhancements
- **VishwamAIModel**: Enhanced the model to address tensor conversion issues and ensure compatibility between TensorFlow and PyTorch.
- **Scoring System**: Improved the scoring system to handle different question types and update scores accordingly.

### Documentation
- **README.md**: Updated to include information about the new features, current status, and next steps for the project.

## Current Status
- Research and review of state-of-the-art methods, academic papers, and benchmarks for MMLU are ongoing.
- Environment setup and necessary packages for interacting with Papers with Code and extracting text from PDFs are complete.
- Key information from relevant model documentation, including the GPT-4 technical report and Gemini model papers, has been extracted and analyzed.
- Performance metrics graphs have been generated and stored as `/home/ubuntu/performance_metrics_graphs.png`.
- Detailed reports for individual MMLU-related papers are being compiled.
- Integration of images and model designs into the research paper is in progress.
- Table 2 with hyper-parameters for the LLaMA models has been added to the research paper outline.
- Auto-update and continuous evaluation features have been implemented.
- Integration with the `grok-1` model is under assessment.

## Next Steps
- Continue collecting and analyzing research papers related to the MMLU projects.
- Compile detailed reports on each MMLU project.
- Integrate images and model designs into the research paper.
- Write the research paper, including all formulas and data training models.
- Compile a list of successful strategies and techniques used in top-performing models.
- Analyze the architecture and training methods of leading models.
- Develop a plan for implementing and testing these strategies.
- Report findings and recommendations for achieving 100% on MMLU.
- Generate our own MMLU model after thorough research and development.
- Validate the auto-update and continuous evaluation features.
- Finalize the integration with the `grok-1` model.

## Contact
For any questions or further information, please contact Devin AI and Kasinadhsarma.

[This Devin run](https://preview.devin.ai/devin/1a3a07b1007044d988dc2c8219ec5228) was requested by kasinadhsarma.
