Be excellent to each other.
