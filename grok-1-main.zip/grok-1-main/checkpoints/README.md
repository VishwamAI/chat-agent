# Checkpoint directory

Place Grok-1 checkpoints here so they can be loaded by the example script.
